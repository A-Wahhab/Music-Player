
<div class="sideBarContainer">
<input type="checkbox" id="check"></input>
    <label for="check">
      <i class="fa fa-bars" id="btn"></i>
      <i class="fa fa-times" id="cancel"></i>
    </label>
    <div class="sidebar">
        <span role="link" tabindex="0" onclick="openPage('index.php')" class="logo">
			<img src="assets/images/LOGO.png">
		</span>
        <div class="navItem">
				<span role='link' tabindex='0' onclick='openPage("search.php")' class="navItemLink SearchBar">
					<p>Search</p>
					<img src="assets/images/icons/search.png" class="icon" alt="Search">
				</span>
			</div>

        <div class="navItem">
				<span role="link" tabindex="0" onclick="openPage('browse.php')" class="navItemLink">Browse</span>
			</div>
			<div class="navItem">
				<span role="link" tabindex="0" onclick="openPage('yourMusic.php')" class="navItemLink">Your Music</span>
			</div>
			<div class="navItem">
				<span role="link" tabindex="0" onclick="openPage('settings.php')" class="navItemLink"><?php echo $_SESSION['user'] ?></span>
			</div>
		<div class="group">
			
		</div>
    </div>
</div>